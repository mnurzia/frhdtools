#Segment.py - Freerider HD Track Segments
#by maxmillion18
#http://www.github.com/maxmillion18
#http://www.freeriderhd.com/u/MaxwellNurzia

from frhdtools import Decode, Encode